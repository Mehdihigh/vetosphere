import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { SaveJwtToken } from "../services/utils/auth.ts";
import {login, checkCode, newPassword, sendEmailCode} from "../services/api/authApi.ts";
import ROUTES from "../config/routeCongif.ts";


export const useLogin = (setIsAuthenticated: React.Dispatch<React.SetStateAction<boolean>>) => {
    const [isLoading, setIsLoading] = useState(false);
    const navigate = useNavigate();

    const loginHandler = async (email: string, password: string) => {
        setIsLoading(true);
        try {

            const response = await login(email, password);

            if (response.status === 200) {
                const data = response.data;
                SaveJwtToken(data.token);
                setIsAuthenticated(true);
                navigate(ROUTES.HOME);
            } else {

                throw new Error("Email ou mot de passe incorrect");
            }
        } catch (error) {

            throw error;
        } finally {
            setIsLoading(false);
        }
    };

    return { isLoading, loginHandler };
};


export const useSendEmailCode = (email: string, nextStep: () => void) => {
    const [isLoading, setIsLoading] = useState(false);

    const sendEmailCodeHandler = async () => {
        setIsLoading(true);
        try {
            const response = await sendEmailCode(email);

            if (response.status === 204) {
                nextStep();
            } else {

            }
        } catch (error) {
            throw error;

        } finally {
            setIsLoading(false);
        }
    };

    return { isLoading, sendEmailCodeHandler };
};

export const useCheckCode = (email: string, code: string, nextStep: () => void) => {
    const [isLoading, setIsLoading] = useState(false);

    const checkCodeHandler = async () => {
        setIsLoading(true);
        try {
            const response = await checkCode(email, code);

            if (response.status === 204) {
                nextStep();
            } else {

            }
        }catch (error) {
            throw error;

        }finally {
            setIsLoading(false)
        }
    }

    return {isLoading, checkCodeHandler}
}

export const useNewPassword = (email: string, password: string, nextStep: () => void) => {
    const [isLoading, setIsLoading] = useState(false);


    const newPasswordHandler = async () => {
        setIsLoading(true);
        try {
            const response = await newPassword(email, password);

            if (response.status === 204) {
                nextStep()
            } else {

            }
        } catch (error) {
            throw error;

        } finally {
            setIsLoading(false);
        }
    }
    return {isLoading, newPasswordHandler};
};