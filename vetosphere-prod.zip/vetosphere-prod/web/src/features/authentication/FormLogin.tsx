import React, { useState } from "react";
import Button from "../../components/common/button/Button.tsx";
import Input from "../../components/common/form/Input.tsx";
import { useAuth } from "../../context/AuthContext"; // Importer le hook useAuth

interface FormLoginProps {
    setEmail: React.Dispatch<React.SetStateAction<string>>;
    email: string;
    setPassword: React.Dispatch<React.SetStateAction<string>>;
    password: string;
    handleForgetPassword: () => void;
}

const FormLogin: React.FC<FormLoginProps> = ({
                                                 setEmail,
                                                 email,
                                                 setPassword,
                                                 password,
                                                 handleForgetPassword
                                             }) => {
    const [showPassword, setShowPassword] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const { login } = useAuth();


    const handleLogin = async (event: React.FormEvent) => {
        setIsLoading(true);
        event.preventDefault();
        try {
            await login(email, password);
            setIsLoading(false);
        } catch (error) {
            setIsLoading(false);
        }
    };

    return (
        <>
            {isLoading ? (
                <div className="flex items-center justify-around max-h-[70%]">
                    <p>Chargement...</p>
                </div>
            ) : (
                <form
                    className="w-full h-[60%] relative flex justify-center items-center flex-col"
                    onSubmit={handleLogin}
                >
                    <div className="w-[70%]">
                        <div>
                            <Input
                                isRequired={true}
                                type="email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="w-full px-3 py-3  my-2 bg-white border border-gray-300 rounded-[4px] text-sm"
                                placeholder="nom@email.com"
                            />
                        </div>
                        <div>
                            <Input
                                isRequired={true}
                                type="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="w-[95%] h-[45px] px-3 py-3 my-2 bg-white border border-gray-300 rounded-l-[4px] text-sm"
                                placeholder="**********"
                                showPassword={showPassword}
                                toggleShowPassword={() => setShowPassword(!showPassword)}
                            />
                        </div>
                    </div>

                    <div className={"w-[70%] item-start"}>
                        <p onClick={handleForgetPassword} className="cursor-pointer">
                            Mot de passe oublié?
                        </p>
                    </div>

                    <div className={"w-[70%]"}>
                        <Button type="submit" typeClass="colorButton" content="Se connecter" />
                    </div>
                </form>
            )}
        </>
    );
};

export default FormLogin;
