import React, { useState, useEffect, useRef } from 'react';
import Autosuggest from 'react-autosuggest';
import '../../../assets/styles/component/autocomplete.css';
import { GetSuggestions } from "../../../api/base/api";
import { useNavigate } from 'react-router-dom';


const SearchPatientAutocomplete = ({ className, onSuggestionSelected, infoUser }) => {
    const [value, setValue] = useState(infoUser || '');
    const [suggestions, setSuggestions] = useState([]);
    const [isOpen, setIsOpen] = useState(false);
    const navigate = useNavigate();
    const inputRef = useRef(null);

    const onSuggestionsFetchRequested = async ({ value }) => {
        if (value.length >= 2) {
            const fetchedSuggestions = await GetSuggestions(value);
            const updatedSuggestions = [...fetchedSuggestions];
            setSuggestions(updatedSuggestions);
            setIsOpen(true);
        }
    };

    const onSuggestionsClearRequested = () => {
        setSuggestions([]);
        setIsOpen(false);
    };

    const renderSuggestion = (suggestion) => (
        <div>
            {suggestion.label}
        </div>
    );

    useEffect(() => {
        if (infoUser !== null) {
            setValue(infoUser);
        }
    }, [className, infoUser]);

    const handleSuggestionSelected = (event, { suggestion }) => {

        onSuggestionSelected(event, { suggestion });

        setSuggestions([]);
        setIsOpen(false);

        setTimeout(() => {
            if (inputRef.current) {
                inputRef.current.blur();
            }
        }, 0);
    };

    const handleBlur = () => {
        setTimeout(() => {
            setIsOpen(false);
        }, 200);
    };

    return (
        <Autosuggest
            suggestions={suggestions}
            onSuggestionsFetchRequested={onSuggestionsFetchRequested}
            onSuggestionsClearRequested={onSuggestionsClearRequested}
            getSuggestionValue={(suggestion) => suggestion.label}
            renderSuggestion={renderSuggestion}
            inputProps={{
                placeholder: 'Rechercher...',
                value: value || '',
                onChange: (_, { newValue }) => setValue(newValue),
                onFocus: () => setIsOpen(true),
                onBlur: handleBlur,
                ref: inputRef
            }}
            onSuggestionSelected={handleSuggestionSelected}
            highlightFirstSuggestion
            theme={{
                container: 'relative bg-transparent border-none lg:h-7/10 w-full rounded-full text-base text-lg',
                suggestionsContainerOpen: 'absolute bg-white p-2 z-30 shadow-lg rounded-lg w-full max-w-full min-h-64 top-14 text-main-color overflow-x-auto text-md',
                suggestion: 'cursor-pointer p-1 rounded-md hover:bg-second-color text-base',
                input: 'w-full h-11 px-3 block border border-gray-300 rounded-lg text-sm',
            }}
        />

    );
};

export default SearchPatientAutocomplete;
