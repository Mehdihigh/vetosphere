import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction";
import frLocale from "@fullcalendar/core/locales/fr";
import FullCalendar from "@fullcalendar/react";
import React, { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import {Event} from "../../../entities/event/Event.ts";
import "../../../assets/styles/view/event.css";

interface CalendarProps {
    initialView: string;
    className?: string;
    eventList: Event[];
    datesSet: (info: { startStr: string, endStr: string}) => void;
}

const Calendar: React.FC<CalendarProps> = ({ initialView, className, eventList, datesSet }) => {
    const calendarRef = useRef(null);
    const navigate = useNavigate();


    return (
        <div className={"w-full h-full border rounded-lg p-4 bg-white shadow-lg overflow-auto flex " + className}>

            <FullCalendar
                ref={calendarRef}
                plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
                initialView={initialView}
                locale={frLocale}
                timeZone="Europe/Paris"
                nowIndicator={true}
                slotLabelInterval="01:00:00"
                slotDuration="00:30:00"
                slotMinTime="09:00"
                slotMaxTime="18:00"
                allDaySlot={false}
                headerToolbar={{
                    start: "prev,next today",
                    center: "title",
                    end: "",
                }}
                height="auto"
                titleFormat={{ year: "numeric", month: "short", day: "numeric" }}
                hiddenDays={[0, 6]}
                editable={true}
                events={[...eventList]}
                dateClick={() => console.log("la")}
                datesSet={(info) => {
                    datesSet({ startStr: info.startStr, endStr: info.endStr });
                }}
                eventClick={(info) => {
                    const id_user = info.event.extendedProps.user.id_user;
                    if (id_user) {
                        navigate(`/patient/${id_user}`);
                    }
                }}
                eventContent={(arg: any) => {
                    let eventClass = "";
                    if (arg.event.extendedProps.state === "Vue") {
                        eventClass = "opacity-50";
                    } else if (arg.event.extendedProps.state === "Absence excusée") {
                        eventClass = "line-through";
                    } else if (arg.event.extendedProps.state === "Absence non excusée") {
                        eventClass = "line-through text-red-500";
                    } else {
                        eventClass = "opacity-100";
                    }

                    return (
                        <div className={`pl-2 ${eventClass}`}>
                            <div className="flex justify-between items-center">
                                <span className="font-bold">{arg.timeText.split(" ")[0]} {" "}</span>
                                <span className="bg-gray-200 px-2 py-1 rounded-md">
                                    {arg.event.extendedProps.user?.firstname} {arg.event.extendedProps.user?.lastname}
                                </span>
                            </div>
                            <div className="mt-1 text-sm">
                                <p>{arg.event.extendedProps.description}</p>
                            </div>
                        </div>
                    );
                }}
            />
        </div>
    );
};

export default Calendar;
