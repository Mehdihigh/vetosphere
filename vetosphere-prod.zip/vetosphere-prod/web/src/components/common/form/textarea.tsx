import React, {useEffect, useState} from 'react';
import '../../assets/styles/component/textarea.css'

const Textarea = ({placeholder,className,onChange,value}) => {
    const [classNameSelected, setClassNameSelected] = useState('');
    useEffect(() => {
        if (className === "default") {
            setClassNameSelected("w-full h-full p-2 block border border-gray-300 rounded-lg text-sm resize-none")
            //setClassNameSelected("border-2 border-base-linear-gradient w-full p-4 rounded-lg mb-4")
        }else{
            setClassNameSelected(className)
        }
    }, [className]);

    return (
            <textarea className={classNameSelected} placeholder={placeholder} onChange={onChange}  value={value}/>
    )

}
export default Textarea