import React, { useState } from "react";
import FormLogin from "../features/authentication/FormLogin";
import { CircleHelp } from 'lucide-react';
import SendEmailLogin from "../features/authentication/SendEmailLogin.tsx";
import { ArrowLeft } from 'lucide-react';
import CheckCode from "../features/authentication/CheckCode.tsx";
import NewPassword from "../features/authentication/NewPassword.tsx";

const Login: React.FC = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [currentStep, setCurrentStep] = useState<"form" | "sendEmail" | "checkCode" | "newPassword">("form");



    const handleStepChange = (step: "form" | "sendEmail" | "checkCode" | "newPassword") => {
        setCurrentStep(step);
    };


    return (
        <div className="flex justify-center items-center absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[1000px] h-[600px] shadow-lg shadow-black/40 z-10">
            <div className="w-1/2 h-full bg-gradient-to-r from-[#90b8c1] to-[#699099]"></div>

            <div className="w-1/2 h-full bg-gray-50 p-2">
                <div className="h-1/10 w-full flex justify-between items-center">
                    <div>
                        <ArrowLeft onClick={() => handleStepChange("form")} className="cursor-pointer"/>
                    </div>
                    <div className="flex items-center justify-around">
                        <p>Aide</p>
                        <CircleHelp/>
                    </div>

                </div>

                <div className="flex items-center justify-around">
                    <p>Connexion</p>
                </div>

                {currentStep === "form" && <FormLogin
                    setEmail={setEmail}
                    email={email}
                    setPassword={setPassword}
                    password={password}
                    handleForgetPassword={() =>  setCurrentStep("sendEmail")}
                />}

                {currentStep === "sendEmail" && <SendEmailLogin
                    setEmail={setEmail}
                    email={email}
                    nextStep={() => setCurrentStep("checkCode")}
                />}

                {currentStep === "checkCode" && <CheckCode
                    email={email}
                    nextStep={() => setCurrentStep("newPassword")}
                />}

                {currentStep === "newPassword" && <NewPassword
                    email={email}
                    nextStep={() => setCurrentStep("form")}
                />}

            </div>
        </div>
    );
};

export default Login;

