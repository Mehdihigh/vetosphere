const Home: React.FC = () => {


    return (
        <div className="w-full h-full pb-4 flex space-x-2">
            HOME
        </div>
    );
};

export default Home;

