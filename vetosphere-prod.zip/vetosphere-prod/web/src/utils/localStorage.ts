
//export function localSelectedAudioCenter(audioCenter){
//    localStorage.setItem('selectedAudioCenter', audioCenter);
//}
//
//export function lastPatientVisited(id_patient){
//    localStorage.setItem('lastPatientVisited', id_patient);
//}