import './App.css';
import { BrowserRouter as Router } from 'react-router-dom';
import { AuthProvider } from "./context/AuthContext.tsx";
import AppLayout from "./routes/AppLayout.tsx";

function App(): JSX.Element {


  return (
    <Router>
      <AuthProvider>
          <AppLayout />
      </AuthProvider>
    </Router>
  );
}

export default App;
