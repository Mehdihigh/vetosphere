import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Login from '../pages/Login';
import ROUTES from "../config/routeCongif.ts";
import Home from "../pages/Home.tsx";


const AppRoutes: React.FC = () => {
    return (
        <main className="w-full h-7/8 pb-1 lg:pb-0 pt-8 px-4 lg:pt-0">
            <Routes>
                <Route path={ROUTES.LOGIN} element={<Login/>}/>
                <Route path={ROUTES.HOME} element={<Home/>}/>
            </Routes>
        </main>
    );
};

export default AppRoutes;