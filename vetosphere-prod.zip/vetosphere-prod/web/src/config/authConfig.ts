const AUTH = {
    TOKEN_KEY: "jwtToken",
    REFRESH_TOKEN_KEY: "refreshToken",
    LAST_ACTIVITY: "lastActivity",
    ROLES: {
        ADMIN: "admin",
        USER: "user",
        GUEST: "guest",
    },
};

export default AUTH;
