const ROUTES = {
    HOME: "/",
    LOGIN: "/connexion",
};

export default ROUTES;
