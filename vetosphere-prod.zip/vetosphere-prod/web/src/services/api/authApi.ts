import axios from "axios";
import {CONFIG} from "../../config/config.ts";

export const login = async (email: string, password: string) => {
    try {
        return await axios.post(`${CONFIG.API_BASE_URL}/auth/login`, {email, password});
    }catch (error) {
        if (error instanceof Error) {
            throw new Error(`Erreur lors de l'envoi du code par email: ${error.message}`);
        }
        throw new Error("Erreur inconnue lors de l'envoi du code par email");
    }
}

export const sendEmailCode = async (email: string) => {
    try {
        return await axios.post(`${CONFIG.API_BASE_URL}/auth/creat-send-code-password`, { email });
    } catch (error) {
        if (error instanceof Error) {
            throw new Error(`Erreur lors de l'envoi du code par email: ${error.message}`);
        }
        throw new Error("Erreur inconnue lors de l'envoi du code par email");
    }
};

export const checkCode = async (email: string, code: string) => {
    try {
        const data = {
            email: email,
            code_reset: code,
        };
        return await axios.post(`${CONFIG.API_BASE_URL}/auth/check-code`, data);
    } catch (error) {
        if (error instanceof Error) {
            throw new Error(`Erreur lors de la vérification du code: ${error.message}`);
        }
        throw new Error("Erreur inconnue lors de la vérification du code");
    }
};

export const newPassword = async (email: string, password: string)=> {
    try {
        return await axios.post(`${CONFIG.API_BASE_URL}/auth/new-password`, { email, password });
    } catch (error) {

        if (error instanceof Error) {
            throw new Error(`Erreur lors du changement de mot de passe: ${error.message}`);
        }
        throw new Error("Erreur inconnue lors du changement de mot de passe");
    }
};