import { confirmEmail } from './confirm-email.template';
export default class MailTemplate {
  static confirmEmail = confirmEmail;
}
