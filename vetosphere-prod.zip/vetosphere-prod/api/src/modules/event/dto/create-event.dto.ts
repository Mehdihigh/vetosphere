export class CreateEventDto {}
