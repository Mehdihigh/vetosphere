export class CreateSpecieDto {}
