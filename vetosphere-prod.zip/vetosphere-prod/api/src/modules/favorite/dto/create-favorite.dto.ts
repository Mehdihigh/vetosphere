export class CreateFavoriteDto {}
