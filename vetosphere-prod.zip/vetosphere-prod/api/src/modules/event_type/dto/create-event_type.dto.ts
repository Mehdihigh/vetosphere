export class CreateEventTypeDto {}
