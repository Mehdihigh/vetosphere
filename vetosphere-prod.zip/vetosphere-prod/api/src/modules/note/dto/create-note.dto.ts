export class CreateNoteDto {}
