export enum DayEnum {
  'lundi' = 'lundi',
  'mardi' = 'mardi',
  'mercredi' = 'mercredi',
  'jeudi' = 'jeudi',
  'vendredi' = 'vendredi',
  'samedi' = 'samedi',
  'dimanche' = 'dimanche',
}
