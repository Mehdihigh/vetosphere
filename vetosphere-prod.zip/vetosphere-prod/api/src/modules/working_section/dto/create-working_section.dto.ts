export class CreateWorkingSectionDto {}
