export class CreatePhotoDto {}
