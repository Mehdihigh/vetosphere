export class CreateBlogDto {}
