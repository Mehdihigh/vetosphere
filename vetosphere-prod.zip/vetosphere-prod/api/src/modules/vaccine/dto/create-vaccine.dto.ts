export class CreateVaccineDto {}
