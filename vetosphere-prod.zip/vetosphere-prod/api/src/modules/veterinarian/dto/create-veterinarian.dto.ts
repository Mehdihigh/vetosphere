export class CreateVeterinarianDto {}
