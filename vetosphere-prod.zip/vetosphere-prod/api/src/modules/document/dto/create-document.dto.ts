export class CreateDocumentDto {}
