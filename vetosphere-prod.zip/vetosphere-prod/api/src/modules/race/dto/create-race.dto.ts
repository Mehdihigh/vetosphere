export class CreateRaceDto {}
