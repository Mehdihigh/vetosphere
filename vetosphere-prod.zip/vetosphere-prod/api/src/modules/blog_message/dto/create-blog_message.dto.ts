export class CreateBlogMessageDto {}
