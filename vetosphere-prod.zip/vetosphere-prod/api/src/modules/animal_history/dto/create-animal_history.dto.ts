export class CreateAnimalHistoryDto {}
