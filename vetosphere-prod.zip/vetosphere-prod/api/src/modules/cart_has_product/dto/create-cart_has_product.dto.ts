export class CreateCartHasProductDto {}
