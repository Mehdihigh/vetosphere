export class CreateAnimalDto {}
