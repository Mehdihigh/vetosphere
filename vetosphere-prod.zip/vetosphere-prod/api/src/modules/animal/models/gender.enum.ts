export enum GenderEnum {
  'mâle' = 'mâle',
  'femelle' = 'femelle',
}
