export class CreateVaccinationDto {}
