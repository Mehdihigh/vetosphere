export enum CivilityEnum {
  'm.' = 'm.',
  'mme.' = 'mme.',
  'autre' = 'autre',
}
