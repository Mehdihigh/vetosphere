export enum RoleEnum {
  'admin' = 'admin',
  'veterinarian' = 'veterinarian',
  'client' = 'client',
}
