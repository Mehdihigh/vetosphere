export enum DeliveryEnum {
  'Commandée' = 'Commandée',
  'Préparation.' = 'Préparation',
  'Expédié' = 'Expédié',
  'En cours de livraison' = 'En cours de livraison',
  'Livrée' = 'Livrée',
}
