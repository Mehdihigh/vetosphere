export class CreateDeliveryStageDto {}
