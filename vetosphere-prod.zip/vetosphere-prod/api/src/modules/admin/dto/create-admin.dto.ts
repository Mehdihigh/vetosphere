export class CreateAdminDto {}
