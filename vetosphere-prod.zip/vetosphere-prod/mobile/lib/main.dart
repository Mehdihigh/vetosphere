import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:im_audio_mobile/presentation/event/screen/event_screen.dart';
import 'package:im_audio_mobile/presentation/home/screen/home_screen.dart';
import 'package:im_audio_mobile/presentation/login/screen/login_screen.dart';
import 'package:shadcn_ui/shadcn_ui.dart';

import 'core/check/auth_check.dart';

void main() {
  runApp(ProviderScope(child: const MyApp()));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ShadApp.cupertino(
      cupertinoThemeBuilder: (context, theme) {
        return theme.copyWith(applyThemeToAll: true);
      },
      materialThemeBuilder: (context, theme) {
        return theme.copyWith(
          appBarTheme: const AppBarTheme(toolbarHeight: 52),
        );
      },

      // Le point d'entrée principal est AuthenticationWrapper.
      home: AuthenticationWrapper(),
      routes: {
        '/login': (context) => const LoginScreen(),
        '/home': (context) => const HomeScreen(),
        '/event': (context) => const EventScreen(),
      },

      // Configuration de la localisation.
      localizationsDelegates: [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('fr', ''),
      ],
    );
  }
}
