import 'dart:io';

import 'package:dio/dio.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:im_audio_mobile/core/cacheManager/jwtStorage.dart';
import 'package:im_audio_mobile/data/api/parameter_api.dart';

import '../../core/error/failure.dart';
import '../model/response/user_response.dart';


final userApiProvider = Provider<UserApi>((ref) => UserApi());

class UserApi{
  Future<UserResponse?> getUserInfo() async{
    try{
      final jwt = await JwtStorage.getToken();

      final dio = Dio();
      dio.options.headers["Authorization"] = "Bearer $jwt";
      dio.options.connectTimeout = 5000;
      dio.options.receiveTimeout = 5000;


      final response = await dio.get(
          "${UrlApi.url}/patient/null"
      );

      if (response.statusCode == 200 && response.data != null){
        final data = Map<String, dynamic>.from(response.data);

        return UserResponse.fromMap(data);
      }
      return null;
    }on DioError catch (err) {
      print("Erreur API : ${err.response?.data}");
      throw Failure(
        message: err.response?.statusMessage ?? 'Une erreur est survenue',
      );
    } on SocketException {
      print("Erreur réseau : Vérifiez votre connexion internet");
      throw Failure(message: 'Vérifiez votre connexion internet');
    }
  }
}