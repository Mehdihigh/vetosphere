import 'dart:io';
import 'package:dio/dio.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:im_audio_mobile/core/cacheManager/jwtStorage.dart';
import 'package:im_audio_mobile/data/api/parameter_api.dart';

import '../../core/error/failure.dart';
import '../model/response/user_document_response.dart';

final userDocumentApiProvider = Provider<UserDocumentApi>((ref) => UserDocumentApi());

class UserDocumentApi {
  Future<List<UserDocumentResponse>> getDocumentsByUser() async {
    try {
      final jwt = await JwtStorage.getToken();
      final dio = Dio();

      final response = await dio.get(
        "${UrlApi.url}/user-document/get-by-user/null",
        options: Options(
          headers: {
            "Authorization": "Bearer $jwt",
            "Accept": "application/json",
          },
        ),
      );

      if (response.statusCode == 200 && response.data != null) {
        final List<dynamic> jsonList = response.data as List<dynamic>;

        return jsonList
            .map((json) => UserDocumentResponse.fromMap(json as Map<String, dynamic>))
            .toList();
      }

      return [];

    } on DioError catch (err) {
      print("Erreur API : ${err.response?.data}");
      throw Failure(
        message: err.response?.statusMessage ?? 'Une erreur est survenue',
      );
    } on SocketException {
      print("Erreur réseau : Vérifiez votre connexion internet");
      throw Failure(message: 'Vérifiez votre connexion internet');
    }
  }
}
