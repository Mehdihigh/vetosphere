import 'dart:io';

import 'package:dio/dio.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:im_audio_mobile/core/cacheManager/jwtStorage.dart';
import 'package:im_audio_mobile/data/api/parameter_api.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/error/failure.dart';
import '../model/request/auth_request.dart';
import '../model/response/auth_response.dart';

final AuthApiProvider = Provider<AuthApi>((ref) => AuthApi());


class AuthApi {
  Future<AuthResponse?> login(String email, String password) async {
    try {
      print("Appel de l'API : ${UrlApi.url}/auth/login");

      // Effectuer la requête POST
      final response = await Dio().post(
        "${UrlApi.url}/auth/login",
        data:AuthRequest(email: email, password: password)
      );

      print("Réponse API : ${response.data}");

      // Vérifier le statut HTTP
      if (response.statusCode == 200) {
        final data = Map<String, dynamic>.from(response.data);

        // Vérifier si un token est présent
        if (data["token"] != null && data["token"].isNotEmpty) {
          final auth = AuthResponse.fromMap(data);

          await JwtStorage.saveToken(data['token']);

          return auth;
        } else {
          print("Token manquant dans la réponse.");
          return null;
        }
      } else {
        // Gérer les autres cas de réponse
        print("Erreur inattendue avec le statut : ${response.statusCode}");
        return null;
      }
    } on DioError catch (err) {
      print("Erreur Dio : ${err.response?.statusMessage}");

      // Gérer les erreurs HTTP spécifiques
      if (err.response?.statusCode == 400) {
        print("Identifiants incorrects (400)");
        return null; // Retourner null pour continuer l'exécution
      }

      // Relancer l'exception pour d'autres erreurs
      throw Failure(message: err.response?.statusMessage ?? 'Une erreur réseau est survenue.');
    } on SocketException catch (err) {
      print("Erreur réseau : $err");
      throw Failure(message: 'Vérifiez votre connexion Internet.');
    } catch (err) {
      print("Erreur inconnue : $err");
      throw Failure(message: 'Une erreur inattendue est survenue.');
    }
  }
}

