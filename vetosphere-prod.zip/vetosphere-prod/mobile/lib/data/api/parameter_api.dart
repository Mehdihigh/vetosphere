import 'package:hooks_riverpod/hooks_riverpod.dart';

final UrlApiProvider = Provider<UrlApi>((ref) => UrlApi());

class UrlApi {
  static String _url = 'http://91.134.96.11:8000';//http://91.134.96.11:8000

  static String get url => _url;

  static void setUrl(String newUrl) {
    _url = newUrl;
  }
}


//Future<String?> getToken() async {
//  final prefs = await SharedPreferences.getInstance();
//  return prefs.getString('auth_token');
//}
//
//Future<String?> getToken() async {
//  try {
//    final prefs = await SharedPreferences.getInstance();
//    return prefs.getString('auth_token');
//  } catch (e) {
//    print('Erreur lors de la récupération du token : $e');
//    return null;
//  }
//}