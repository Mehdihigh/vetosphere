import 'dart:io';
import 'package:dio/dio.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:im_audio_mobile/data/api/parameter_api.dart';
import 'package:im_audio_mobile/data/model/request/event_request.dart';

import '../../core/cacheManager/jwtStorage.dart';
import '../../core/error/failure.dart';
import '../model/response/event_response.dart';

final eventApiProvider = Provider<EventApi>((ref) => EventApi());

class EventApi {

  Future<List<EventResponse>> getFreeAppointments(String date) async {
    try {
      final jwt = await JwtStorage.getToken();

      final dio = Dio();
      dio.options.headers["Authorization"] = "Bearer $jwt";
      dio.options.connectTimeout = 5000;
      dio.options.receiveTimeout = 5000;

      print("En-têtes envoyés : ${dio.options.headers}");
      final response = await dio.get(
        "${UrlApi.url}/event/to-patient",
        queryParameters: EventRequest.toMapForGetFreeAppointments(
          date: date,
          audioCenter: 1,
        ),
      );

      if (response.statusCode == 200 && response.data != null) {
        final List<dynamic> jsonList = response.data as List<dynamic>;

        return jsonList
            .map((json) => EventResponse.fromMap(json as Map<String, dynamic>))
            .toList();
      }

      return [];
    } on DioError catch (err) {
      print("Erreur API : ${err.response?.data}");
      throw Failure(
        message: err.response?.statusMessage ?? 'Une erreur est survenue',
      );
    } on SocketException {
      print("Erreur réseau : Vérifiez votre connexion internet");
      throw Failure(message: 'Vérifiez votre connexion internet');
    }
  }

}
