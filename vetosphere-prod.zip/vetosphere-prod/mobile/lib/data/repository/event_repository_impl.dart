import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:im_audio_mobile/data/api/event_api.dart';

import '../../../domain/entity/slot.dart';
import '../../domain/repository/event_repository.dart';

final eventRepositoryProvider = Provider<EventRepository>(
      (ref) => EventRepositoryImpl(ref.read(eventApiProvider)),
);

class EventRepositoryImpl extends EventRepository {
  final EventApi _eventApi;

  EventRepositoryImpl(this._eventApi);

  @override
  Future<List<Slot>> getFreeAppointments({required String date}) async {

    final responses = await _eventApi.getFreeAppointments(date);
    return responses.map((response) {
      return Slot(
        slot: response.slot,
        setting: response.setting,
        test: response.test,
      );
    }).toList();
  }
}
