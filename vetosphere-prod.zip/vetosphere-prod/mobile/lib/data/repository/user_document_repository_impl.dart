import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:im_audio_mobile/data/api/user_document_api.dart';
import '../../domain/entity/document.dart';
import '../../domain/repository/document_repository.dart';
import '../model/response/user_document_response.dart';

final userDocumentRepositoryProvider = Provider<DocumentRepository>(
      (ref) => UserDocumentRepositoryImpl(ref.read(userDocumentApiProvider)),
);

class UserDocumentRepositoryImpl extends DocumentRepository {
  final UserDocumentApi _userDocumentApi;

  UserDocumentRepositoryImpl(this._userDocumentApi);

  @override
  Future<List<Document>> getDocumentsByUser() async {
    try {
      final List<UserDocumentResponse> documentResponses = await _userDocumentApi.getDocumentsByUser();

      if (documentResponses.isEmpty) {
        throw Exception("Aucun document trouvé pour cet utilisateur.");
      }

      final List<Document> documents = documentResponses.map((response) {
        return Document(
          id: response.id,
          fileName: response.fileName,
          type: response.type,
          createdAt: response.createdAt,
          worker: response.worker,
        );
      }).toList();

      return documents;

    } catch (e) {
      throw Exception("Erreur lors de la récupération des documents : $e");
    }
  }
}
