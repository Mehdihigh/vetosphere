import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:im_audio_mobile/data/api/auth_api.dart';

import '../../domain/entity/auth.dart';
import '../../domain/repository/auth_repository.dart';

final authRepositoryProvider =
    Provider<AuthRepository>((ref) => AuthRepositoryImpl(ref.read(AuthApiProvider)));

class AuthRepositoryImpl extends AuthRepository{
  final AuthApi _authApi;

  AuthRepositoryImpl(this._authApi);

  @override
  Future<Auth?> authentication({required String email, required String password}) async {
    final response = await _authApi.login(email, password);
    return response != null ? response.toEntity() : null;
  }
}