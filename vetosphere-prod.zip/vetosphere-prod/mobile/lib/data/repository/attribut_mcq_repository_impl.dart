import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:im_audio_mobile/domain/entity/attribut_mcq.dart';

import '../../domain/repository/attribut_mcq_repository.dart';
import '../api/attribut_mcq_api.dart';

final attributMcqRepositoryProvider = Provider<AttributMcqRepository>(
        (ref) => AttributMcqRepositoryImpl(ref.read(attributMcqApiProvider))
);

class AttributMcqRepositoryImpl extends AttributMcqRepository{
  final AttributMcqApi _attributMcqApi;

  AttributMcqRepositoryImpl(this._attributMcqApi);

  @override
  Future<List<AttributMcq>> getMcqByPatient() async {
    final response = await _attributMcqApi.getMcqByPatient();
    return response.map((response) {
      return AttributMcq(
          state: response.state,
          mcq: response.mcq
      );
    }).toList();
  }
}