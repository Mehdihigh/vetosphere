import 'package:flutter/cupertino.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:im_audio_mobile/data/api/user_api.dart';
import '../../domain/entity/user.dart';
import '../../domain/repository/user_repository.dart';
import '../model/response/user_response.dart';

final userRepositoryProvider = Provider<UserRepository>(
      (ref) => UserRepositoryImpl(ref.read(userApiProvider)),
);

class UserRepositoryImpl extends UserRepository {
  final UserApi _userApi;

  UserRepositoryImpl(this._userApi);

  @override
  Future<User> getUserInfo() async {
    try {
      final UserResponse? response = await _userApi.getUserInfo();

      if (response == null) {
        throw Exception("Erreur : Aucune donnée utilisateur reçue.");
      }

      return response.user;
    } catch (e, stackTrace) {
      debugPrint("[UserRepository] Erreur lors de la récupération des infos utilisateur: $e");
      debugPrint(stackTrace.toString());
      throw Exception("Erreur lors de la récupération des informations utilisateur : $e");
    }
  }
}
