import 'package:equatable/equatable.dart';
import '../../../domain/entity/user.dart';

class UserResponse extends Equatable {
  final User user;

  const UserResponse({
    required this.user,
  });

  @override
  List<Object?> get props => [user];

  factory UserResponse.fromMap(Map<String, dynamic> map) {
    return UserResponse(
      user: User.fromMap(map['patient'] ?? {}),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'patient': user.toMap(),
    };
  }
}
