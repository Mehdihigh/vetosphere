import 'package:equatable/equatable.dart';

import '../../../domain/entity/auth.dart';

class AuthResponse extends Equatable{
  final String jwt;

  const AuthResponse({
    required this.jwt
  });

  @override
  List<Object> get props => [
    jwt,
  ];

  Auth toEntity() {
    return Auth(
      jwt: jwt,
    );
  }

  factory AuthResponse.fromMap(Map<String, dynamic>map){
    return AuthResponse(
      jwt: map['token'] ?? '',
    );
  }
}