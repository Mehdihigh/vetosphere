import 'package:equatable/equatable.dart';
import 'package:im_audio_mobile/domain/entity/attribut_mcq.dart';

import '../../../domain/entity/mcq.dart';

class AttributMcqResponse extends Equatable {
  final String state;
  final Mcq mcq;

  const AttributMcqResponse({
    required this.state,
    required this.mcq,
  });

  @override
  List<Object?> get props => [state, mcq];

  factory AttributMcqResponse.fromMap(Map<String, dynamic> map){
    return AttributMcqResponse(
      state: map['state'] as String,
        mcq: Mcq.fromMap(map['mcq'] as Map<String, dynamic>)
    );
  }

  Map<String, dynamic> toMap(){
    return {
      'state': state,
      'mcq': mcq,
    };
  }
}