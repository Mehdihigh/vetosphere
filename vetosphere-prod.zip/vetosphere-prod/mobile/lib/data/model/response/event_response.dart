import 'package:equatable/equatable.dart';

class EventResponse extends Equatable {
  final String slot;
  final bool setting;
  final bool test;

  const EventResponse({
    required this.slot,
    required this.setting,
    required this.test,
  });

  @override
  List<Object?> get props => [slot, setting, test];

  factory EventResponse.fromMap(Map<String, dynamic> map) {
    return EventResponse(
      slot: map['slot'] as String,
      setting: map['setting'] as bool,
      test: map['test'] as bool,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'slot': slot,
      'setting': setting,
      'test': test,
    };
  }
}
