import 'package:equatable/equatable.dart';
import '../../../domain/entity/document.dart';
import '../../../domain/entity/worker.dart';

class UserDocumentResponse extends Equatable {
  final int id;
  final String fileName;
  final String type;
  final String createdAt;
  final Worker worker;

  const UserDocumentResponse({
    required this.id,
    required this.fileName,
    required this.type,
    required this.createdAt,
    required this.worker,
  });

  @override
  List<Object?> get props => [id, fileName, type, createdAt, worker];

  factory UserDocumentResponse.fromMap(Map<String, dynamic> map) {
    return UserDocumentResponse(
      id: map['id_document'] as int,
      fileName: map['file_name'] ?? '',
      type: map['type'] ?? '',
      createdAt: map['creat'] ?? '',
      worker: Worker.fromMap(map['worker'] ?? {}),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id_document': id,
      'file_name': fileName,
      'type': type,
      'creat': createdAt,
      'worker': worker.toMap(),
    };
  }
}
