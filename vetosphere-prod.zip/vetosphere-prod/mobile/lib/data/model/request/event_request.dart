import 'package:equatable/equatable.dart';

import '../../../core/time/convert.dart';

class EventRequest extends Equatable {
  @override
  List<Object?> get props => [];

  static Map<String, dynamic> toMapForGetFreeAppointments({
    required String date,
    required int audioCenter,
  }) {
    return {
      'date': date,
      'id-audio-center': audioCenter.toString(),
    };
  }
}
