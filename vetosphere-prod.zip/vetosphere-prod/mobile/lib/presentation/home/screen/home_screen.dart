import 'package:flutter/material.dart';
import 'package:im_audio_mobile/presentation/mcq/widget/mcq_item.dart';
import 'package:shadcn_ui/shadcn_ui.dart';
import '../../common/nav_bar.dart';
import '../../event/widget/event_item.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Center(
              child: Text(
                "Prochain RDV",
                style: TextStyle(fontSize: 20),
              ),
            ),
            const EventItem(
              audioCenter: 'Port de Bouc',
              dateStart: '15h00 27/01/2025',
              duration: Duration(hours: 0, minutes: 30),
              color: Color(0xFFFFDCB0),
              eventType: 'Réglage',
            ),

            ShadButton(
              width: double.infinity,
              height: 50,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Text(
                    "Demande de rappel ",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(width: 8),
                  Icon(
                    LucideIcons.phone,
                    color: Colors.white,
                    size: 20,
                  ),
                ],
              ),
              decoration: ShadDecoration(
                gradient: const LinearGradient(
                  colors: [
                    Color(0xFF027595),
                    Color(0xFF027595),
                  ],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                border: ShadBorder.all(
                  radius: BorderRadius.circular(10),
                ),
              ),
            ),

            const SizedBox(height: 8),
            const Center(
              child: Text(
                "QCM en attente",
                style: TextStyle(fontSize: 20),
              ),
            ),

            const McqItem(content: "Premier QCM", numberQuestion: 5, state: "Attente")

          ],
        ),
      ),
      bottomNavigationBar: const NavigationBarApp(
        currentPageIndex: 0,
      ),
    );
  }
}
