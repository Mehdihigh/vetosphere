import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import '../../../core/utils/document_downloader.dart';
import '../../common/nav_bar.dart';
import '../viewModel/account_viewmodel.dart';
import '../viewModel/account_state.dart';

class AccountScreen extends HookConsumerWidget {
  const AccountScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final accountState = ref.watch(accountViewModelProvider);
    final accountViewModel = ref.read(accountViewModelProvider.notifier);

    if (accountState.status == AccountStatus.initial) {
      Future.microtask(() async {
        await accountViewModel.getUserInfo();
        await accountViewModel.getDocumentsByUser();
      });
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text("Profil"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: accountState.status == AccountStatus.correct && accountState.user != null
            ? Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 20),
            _buildInfoRow("Nom :", accountState.user!.lastName),
            _buildInfoRow("Prénom :", accountState.user!.firstName),
            _buildInfoRow("Email :", accountState.user!.email ?? "Non renseigné"),
            _buildInfoRow("Adresse :", accountState.user!.address ?? "Non renseigné"),
            _buildInfoRow("Ville :", accountState.user!.city ?? "Non renseigné"),
            _buildInfoRow("Code postal :", accountState.user!.postalCode ?? "Non renseigné"),
            _buildInfoRow("Date de naissance :", accountState.user!.dateOfBirth ?? "Non renseigné"),
            _buildInfoRow("Âge :", accountState.user!.age != null ? "${accountState.user!.age} ans" : "Non renseigné"),
            _buildInfoRow("Genre :", accountState.user!.gender ?? "Non renseigné"),
            _buildInfoRow("Date de création :", accountState.user!.createdAt ?? "Non renseigné"),
            const SizedBox(height: 20),
            const Divider(),
            const Text("Documents :", style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            accountState.documents != null && accountState.documents!.isNotEmpty
                ? ListView.builder(
              shrinkWrap: true,
              itemCount: accountState.documents!.length,
              itemBuilder: (context, index) {
                final document = accountState.documents![index];
                return ListTile(
                  leading: const Icon(Icons.file_copy),
                  title: Text(document.fileName),
                  subtitle: Text("Type : ${document.type}"),
                  trailing: IconButton(
                    icon: const Icon(Icons.download),
                    onPressed: () async {
                      try {
                        await accountViewModel.downloadDocument(document.id, document.fileName);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text("${document.fileName} téléchargé avec succès !")),
                        );
                      } catch (e) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text("Erreur : $e")),
                        );
                      }
                    },
                  ),
                );
              },
            )
                : const Text("Aucun document disponible."),
          ],
        )
            : accountState.status == AccountStatus.incorrect
            ? const Center(child: Text("Erreur lors du chargement des informations"))
            : const Center(child: CircularProgressIndicator()),
      ),
      bottomNavigationBar: const NavigationBarApp(
        currentPageIndex: 4,
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(width: 10),
          Expanded(
            child: Text(value, style: const TextStyle(color: Colors.black87)),
          ),
        ],
      ),
    );
  }
}
