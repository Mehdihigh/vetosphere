import 'package:equatable/equatable.dart';

import '../../../domain/entity/document.dart';
import '../../../domain/entity/user.dart';

enum AccountStatus {
  initial,
  loading,
  correct,
  incorrect,
}

class AccountState extends Equatable {
  final User? user;
  final AccountStatus status;
  final AccountStatus documentStatus;
  final List<Document> documents;

  const AccountState({
    this.user,
    this.status = AccountStatus.initial,
    this.documentStatus = AccountStatus.initial,
    this.documents = const [],
  });

  factory AccountState.initial() {
    return const AccountState();
  }

  AccountState copyWith({
    User? user,
    AccountStatus? status,
    AccountStatus? documentStatus,
    List<Document>? documents,
  }) {
    return AccountState(
      user: user ?? this.user,
      status: status ?? this.status,
      documentStatus: documentStatus ?? this.documentStatus,
      documents: documents ?? this.documents,
    );
  }

  @override
  List<Object?> get props => [user, status, documentStatus, documents];
}
