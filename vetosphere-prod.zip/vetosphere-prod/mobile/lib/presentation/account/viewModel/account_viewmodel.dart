import 'package:hooks_riverpod/hooks_riverpod.dart';
import '../../../core/utils/document_downloader.dart';
import 'account_state.dart';
import '../../../domain/useCase/user_usecase.dart';
import '../../../domain/useCase/document_usecase.dart';

final accountViewModelProvider = StateNotifierProvider.autoDispose<AccountViewModel, AccountState>(
      (ref) => AccountViewModel(
    ref.read(userUseCaseProvider),
    ref.read(documentUseCaseProvider),
  ),
);

class AccountViewModel extends StateNotifier<AccountState> {
  final UserUseCase userUseCase;
  final DocumentUseCase documentUseCase;

  AccountViewModel(this.userUseCase, this.documentUseCase) : super(AccountState.initial());

  Future<void> getUserInfo() async {
    try {
      state = state.copyWith(status: AccountStatus.loading);

      final user = await userUseCase.getUserInfo();
      if (user != null) {
        state = state.copyWith(user: user, status: AccountStatus.correct);
      } else {
        state = state.copyWith(status: AccountStatus.incorrect);
      }
    } catch (e) {
      state = state.copyWith(status: AccountStatus.incorrect);
    }
  }

  Future<void> getDocumentsByUser() async {
    try {
      state = state.copyWith(documentStatus: AccountStatus.loading);

      final documents = await documentUseCase.getDocumentsByUser();
      if (documents.isNotEmpty) {
        state = state.copyWith(documents: documents, documentStatus: AccountStatus.correct);
      } else {
        state = state.copyWith(documentStatus: AccountStatus.incorrect);
      }
    } catch (e) {
      state = state.copyWith(documentStatus: AccountStatus.incorrect);
    }
  }

  Future<void> downloadDocument(int idDocument, String fileName) async {
    try {
      await DocumentDownloader.downloadDocument(idDocument, "$fileName.pdf");
    } catch (e) {
      throw Exception("Erreur lors du téléchargement : $e");
    }
  }
}
