import 'package:equatable/equatable.dart';
import '../../../domain/entity/attribut_mcq.dart';

enum McqStatus{
  initial,
  correct,
  incorrect,
}

class McqState extends Equatable{
  final List<AttributMcq> attributMcqs;
  final McqStatus status;

  const McqState({
    this.status = McqStatus.initial,
    this.attributMcqs = const [],
  });

  factory McqState.initial() {
    return const McqState(
      status: McqStatus.initial,
      attributMcqs: [],
    );
  }

  bool get answered => status == McqStatus.correct || status == McqStatus.incorrect;

  McqState copyWith({
    McqStatus? status,
    List<AttributMcq>? attributMcqs,
  }) {
    return McqState(
      status: status ?? this.status,
      attributMcqs: attributMcqs ?? this.attributMcqs,
    );
  }

  @override
  List<Object?> get props => [status, attributMcqs];
}