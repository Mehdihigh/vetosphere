import 'package:flutter/cupertino.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:im_audio_mobile/presentation/mcq/viewModel/mcq_state.dart';

import '../../../domain/useCase/attribut_mcq_usecase.dart';

final mcqViewModelProvider = StateNotifierProvider.autoDispose<McqViewModel, McqState>(
      (ref) => McqViewModel(ref.read(attributMcqUseCaseProvider),),
);

class McqViewModel extends StateNotifier<McqState> {
  final AttributMcqUseCase _attributMcqUseCaseUseCase;

  McqViewModel(this._attributMcqUseCaseUseCase) : super(McqState.initial());

  Future<void> getMcqByPatient() async {
    try{
      final mcqList = await _attributMcqUseCaseUseCase.getMcqByPatient();

      if(mcqList != null && mcqList.isNotEmpty){
        state = state.copyWith(
          status: McqStatus.correct,
          attributMcqs: mcqList,
        );
      }
    }catch (e) {
      state = state.copyWith(
        status: McqStatus.incorrect,
        attributMcqs: [],
      );
    }

  }

}