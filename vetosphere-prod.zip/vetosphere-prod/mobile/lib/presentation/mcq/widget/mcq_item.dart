import 'package:flutter/material.dart';

class McqItem extends StatelessWidget {
  final String content;
  final int numberQuestion;
  final String state;


  const McqItem({
    Key? key,
    required this.content,
    required this.numberQuestion,
    required this.state,
  }) : super(key: key);

  static const Color color = Color(0xFFF3B153);

  @override
  Widget build(BuildContext context) {

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      color: state == 'fait' ? Color(0xFF3ADA3A) : color,
      child: SizedBox(
        width: double.infinity,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                content,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF027595),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                "Nombre de question : $numberQuestion",
                style: const TextStyle(fontSize: 16),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
