import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import '../../common/nav_bar.dart';
import '../viewModel/mcq_viewmodel.dart';
import '../widget/mcq_item.dart';

class McqScreen extends HookConsumerWidget {
  const McqScreen({Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context, WidgetRef ref){
    final mcqState = ref.watch(mcqViewModelProvider);
    final mcqViewModel = ref.read(mcqViewModelProvider.notifier);

    useEffect(() {
      mcqViewModel.getMcqByPatient();
    },[]);

    return Scaffold(
      appBar: AppBar(),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (mcqState.attributMcqs.isNotEmpty)
              Expanded(
                child: ListView.builder(
                  itemCount: mcqState.attributMcqs.length,
                  itemBuilder: (context, index) {
                    final mcq = mcqState.attributMcqs[index];
                    return McqItem(
                        content: mcq.mcq.content,
                        numberQuestion: 5,
                        state: mcq.state
                    );
                  },
                ),
              ),
          ],
        ),
      ),
      bottomNavigationBar: const NavigationBarApp(
        currentPageIndex: 2,
      ),
    );
  }
}