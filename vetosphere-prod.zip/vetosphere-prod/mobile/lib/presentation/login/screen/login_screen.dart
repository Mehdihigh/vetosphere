import 'package:flutter/material.dart';
import 'package:shadcn_ui/shadcn_ui.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../viewModel/login_viewmodel.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final formKey = GlobalKey<ShadFormState>();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  bool _isLoading = false;
  bool obscure = true;

  @override
  Widget build(BuildContext context) {
    final bool isKeyboardVisible = MediaQuery.of(context).viewInsets.bottom > 0;

    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: DefaultTextStyle(
        style: const TextStyle(
          fontFamily: 'Inter',
          fontSize: 16,
          color: Colors.black,
        ),
        child: Stack(
          children: [
            Column(
              children: [

                Text('Login'),
                Text('Bienvenue sur votre application'),

                Expanded(
                  child: Center(
                    child: SingleChildScrollView(
                      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                      child: SizedBox(
                        width: MediaQuery.of(context).size.width * 0.9,
                        child: ShadForm(
                          key: formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              ShadInputFormField(
                                id: 'email',
                                controller: emailController,
                                placeholder: const Text('veto@shere.com'),
                                validator: (v) {
                                  if (v.isEmpty || !v.contains('@') || !v.contains('.')) {
                                    return 'Rentrez un email au format valide';
                                  }
                                  return null;
                                },
                                decoration: ShadDecoration(
                                  border: ShadBorder.all(
                                    radius: BorderRadius.circular(5),
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 1,
                                      vertical: 1,
                                    ),
                                  ),
                                  secondaryFocusedBorder: ShadBorder.all(
                                    width: 1,
                                    color: Color(0xFF818CF8),
                                    radius: BorderRadius.circular(7),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 16),

                              ShadInputFormField(
                                id: 'password',
                                controller: passwordController,
                                placeholder: const Text('xxxxxx'),
                                obscureText: obscure,
                                suffix: ShadButton(
                                  width: 24,
                                  height: 24,
                                  padding: EdgeInsets.zero,
                                  decoration: const ShadDecoration(
                                    secondaryBorder: ShadBorder.none,
                                    secondaryFocusedBorder: ShadBorder.none,
                                    gradient: LinearGradient(colors: [
                                      Colors.transparent,
                                      Colors.transparent,
                                    ]),
                                  ),
                                  child: Icon(
                                    obscure ? LucideIcons.eyeOff : LucideIcons.eye,
                                    size: 20,
                                    color: const Color(0xFF818CF8),
                                  ),
                                  onPressed: () {
                                    setState(() {
                                      obscure = !obscure;
                                    });
                                  },
                                ),
                                decoration: ShadDecoration(
                                  border: ShadBorder.all(
                                    radius: BorderRadius.circular(5),
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 1,
                                      vertical: 1,
                                    ),
                                  ),
                                  secondaryFocusedBorder: ShadBorder.all(
                                    width: 1,
                                    color: Color(0xFF818CF8),
                                    radius: BorderRadius.circular(7),
                                  ),
                                ),
                              ),

                     

                              Align(
                                alignment: Alignment.topRight,
                                child: Padding(
                                  padding: const EdgeInsets.only(top: 8),
                                  child: GestureDetector(
                                    onTap: () {
                                      print("Naviguer vers la réinitialisation de mot de passe");
                                    },
                                    child: const Text(
                                      'Mot de passe oublié ?',
                                      style: TextStyle(
                                        color: Color(0xFF818CF8),
                                        fontSize: 14,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
r
                              Consumer(
                                builder: (context, ref, child) {
                                  return Center(
                                    child: ShadButton(
                                      width: MediaQuery.of(context).size.width * 0.7,
                                      height: 50,
                                      child: _isLoading
                                          ? const CircularProgressIndicator(
                                        color: Colors.white,
                                      )
                                          : const Text('Se connecter'),
                                      onPressed: _isLoading
                                          ? null
                                          : () async {
                                        if (formKey.currentState!.saveAndValidate()) {
                                          final email = emailController.text;
                                          final password = passwordController.text;

                                          setState(() {
                                            _isLoading = true;
                                          });

                                          try {
                                            await ref.read(loginViewModelProvider.notifier).authenticate(
                                              email,
                                              password,
                                              context,
                                            );
                                          } catch (e) {
                                            print('Erreur : $e');
                                          } finally {
                                            setState(() {
                                              _isLoading = false;
                                            });
                                          }
                                        } else {
                                          print('Échec de la validation');
                                        }
                                      },

                                      decoration: ShadDecoration(
                                        color: const Color(0xFF818CF8),
                                        border: ShadBorder.all(
                                          radius: BorderRadius.circular(25),
                                        ),
                                        gradient: const LinearGradient(colors: [
                                          Color(0xFF818CF8),
                                          Color(0xFF818CF8),
                                        ]),
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),

            if (!isKeyboardVisible)
              Align(
                alignment: Alignment.bottomCenter,
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 15),
                  child: Text.rich(
                    TextSpan(
                      text: "By ",
                      style: TextStyle(
                        color: Colors.grey[600],
                        fontFamily: 'Inter',
                      ),
                      children: [
                        TextSpan(
                          text: "Vétosphere",
                          style: TextStyle(
                            color: Color(0xFF818CF8),
                            fontFamily: 'Inter',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
