import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../core/check/auth_check.dart';
import '../../../domain/useCase/auth_usecase.dart';
import '../../common/custom_popup.dart';
import 'login_state.dart';

final loginViewModelProvider = StateNotifierProvider.autoDispose<LoginViewModel, LoginState>(
      (ref) => LoginViewModel(ref.read(authUseCaseProvider),),
);

class LoginViewModel extends StateNotifier<LoginState> {
  LoginViewModel(this._useCase) : super(LoginState.initial());
  final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  final AuthUseCase _useCase;

  Future<void> authenticate(String email, String password, BuildContext context) async {
    final auth = await _useCase.authentication(email: email, password: password);

    print("Laaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa: $auth");
    if (auth != null) {
      state = state.copyWith(status: LoginStatus.correct);

      Navigator.pushNamed(context, '/home');
    } else {
      state = state.copyWith(status: LoginStatus.incorrect);

      showDialog(
        context: context,
        builder: (BuildContext context) {
          return CustomPopup(
            title: "Erreur de connexion",
            content: "Mail ou mot de passe incorrect",
            action: "Réessayer",
            onPressed: () => {
              Navigator.of(context).pop()
            },
          );
        },
      );
    }
  }

  Future<void> logout(BuildContext context) async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return CustomPopup(
          title: "Déconnexion",
          content: "En appuyant sur 'Se déconnecter' vous allez être déconnecté de l'application",
          action: "Se déconnecter",
          onPressed: () => {
            // Mise à jour de l'état et navigation
            Navigator.of(context).pop(),
            state = state.copyWith(status: LoginStatus.incorrect),
            Navigator.pushNamed(context, '/login'),
          },
        );
      },
    );
  }


}
