import 'package:equatable/equatable.dart';

enum LoginStatus { correct, incorrect}

class LoginState extends Equatable{
  final String email;
  final String password;
  final LoginStatus status;

  const LoginState({
    required this.email,
    required this.password,
    required this.status,
  });

  @override
  List<Object> get props => [
    email,
    password,
    status,
  ];

  factory LoginState.initial(){
    return LoginState(
      email: '',
      password: '',
      status: LoginStatus.incorrect,
    );
  }

  bool get answerd => status == LoginStatus.incorrect || status == LoginStatus.correct;

  LoginState copyWith({
    String? selectedAnswer,
    int? correct,
    LoginStatus? status,
  }) {
    return LoginState(
      email: email ?? this.email,
      password: password ?? this.password,
      status: status ?? this.status,
    );
  }
}