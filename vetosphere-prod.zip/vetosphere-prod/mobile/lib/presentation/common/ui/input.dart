import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shadcn_ui/shadcn_ui.dart';

class InputWidget extends StatelessWidget {
  final TextEditingController inputController;
  final String placeholder;
  final String? error;

  const InputWidget({
    Key? key,
    required this.inputController,
    required this.placeholder,
    this.error,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 320),
          child: ShadInput(
            controller: inputController,
            placeholder: Text(placeholder),
            keyboardType: TextInputType.emailAddress,
          ),
        ),
        const SizedBox(height: 8),
        // Message d'erreur (optionnel)
        if (error != null && error!.isNotEmpty)
          Text(
            error!,
            style: TextStyle(color: Colors.red),
          ),
      ],
    );
  }
}
