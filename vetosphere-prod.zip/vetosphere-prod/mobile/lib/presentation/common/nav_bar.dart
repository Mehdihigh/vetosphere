import 'package:flutter/material.dart';
import 'package:im_audio_mobile/presentation/account/screen/account_screen.dart';
import 'package:shadcn_ui/shadcn_ui.dart';

import '../event/screen/event_screen.dart';
import '../home/screen/home_screen.dart';
import '../mcq/screen/mcq_screen.dart';

class NavigationBarApp extends StatelessWidget {
  final int currentPageIndex;

  const NavigationBarApp({
    Key? key,
    required this.currentPageIndex,
  }) : super(key: key);

  void _onTabSelected(BuildContext context, int index) {
    if (index != currentPageIndex) {
      Widget page;
      switch (index) {
        case 0:
          page = const HomeScreen();
          break;
        case 1:
          page = const EventScreen();
          break;
        case 2:
          page = const McqScreen();
          break;
        case 4:
          page = const AccountScreen();
          break;
        default:
          return;
      }
      Navigator.pushReplacement(
        context,
        PageRouteBuilder(
          pageBuilder: (context, animation1, animation2) => page,
          transitionDuration: Duration.zero,
          reverseTransitionDuration: Duration.zero,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: currentPageIndex,
      onTap: (index) => _onTabSelected(context, index),
      type: BottomNavigationBarType.fixed,
      selectedItemColor: const Color(0xFF027595),
      unselectedItemColor: const Color(0x88027595),
      selectedFontSize: 12,
      unselectedFontSize: 10,
      items: const [
        BottomNavigationBarItem(
          icon: Icon(LucideIcons.house),
          label: 'Accueil',
        ),
        BottomNavigationBarItem(
          icon: Icon(LucideIcons.calendar),
          label: 'RDV',
        ),
        BottomNavigationBarItem(
          icon: Icon(LucideIcons.clipboardList),
          label: 'QCM',
        ),
        BottomNavigationBarItem(
          icon: Icon(LucideIcons.video),
          label: 'Tuto',
        ),
        BottomNavigationBarItem(
          icon: Icon(LucideIcons.userRound),
          label: 'Profil',
        ),
      ],
    );
  }

}
