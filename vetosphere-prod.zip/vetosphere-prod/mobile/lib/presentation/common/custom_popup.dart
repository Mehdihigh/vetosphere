import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class CustomPopup extends StatelessWidget {
  final String title;
  final String content;
  final String action;
  final VoidCallback  onPressed;
  const CustomPopup({required this.title, required this.content, required this.action, required this.onPressed}) : super();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(title),
      content: Text(content),
      actions: <Widget>[
        TextButton(
          child: Text(action),
          onPressed: onPressed,
        ),
      ],
    );
  }
}