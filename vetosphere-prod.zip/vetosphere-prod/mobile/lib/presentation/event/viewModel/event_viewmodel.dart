import 'package:hooks_riverpod/hooks_riverpod.dart';
import '../../../domain/useCase/event_usecase.dart';
import 'event_state.dart';

final eventViewModelProvider = StateNotifierProvider.autoDispose<EventViewModel, EventState>(
      (ref) => EventViewModel(ref.read(eventUseCaseProvider)),
);

class EventViewModel extends StateNotifier<EventState> {
  final EventUseCase eventUseCase;

  EventViewModel(this.eventUseCase) : super(EventState.initial());

  Future<void> freeAppointments(String date) async {
    try {
      print("HELLO WORLD");
      final freeAppointments = await eventUseCase.getFreeAppointments(date: date);

      if (freeAppointments != null && freeAppointments.isNotEmpty) {
        state = state.copyWith(
          free: "ok",
          status: EventStatus.correct,
          freeSlots: freeAppointments,
        );
      } else {
        state = state.copyWith(
          free: "aucun rendez-vous disponible",
          status: EventStatus.correct,
          freeSlots: [],
        );
      }
    } catch (e) {
      state = state.copyWith(
        free: "erreur",
        status: EventStatus.incorrect,
        freeSlots: [],
      );
    }
  }

}
