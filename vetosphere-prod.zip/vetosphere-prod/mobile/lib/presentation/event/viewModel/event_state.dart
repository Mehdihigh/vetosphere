import 'package:equatable/equatable.dart';
import '../../../domain/entity/slot.dart';

// Enum pour gérer les statuts de l'événement
enum EventStatus {
  initial,
  correct,
  incorrect,
}

// État de l'événement
class EventState extends Equatable {
  final String free; // Message d'état
  final EventStatus status; // Statut actuel
  final List<Slot> freeSlots; // Liste des créneaux disponibles

  const EventState({
    this.free = "",
    this.status = EventStatus.initial,
    this.freeSlots = const [],
  });

  // Création d'un état initial par défaut
  factory EventState.initial() {
    return const EventState(
      free: "",
      status: EventStatus.initial,
      freeSlots: [],
    );
  }

  // Méthode pour savoir si un statut est défini
  bool get answered => status == EventStatus.correct || status == EventStatus.incorrect;

  // Crée une copie de l'état avec des valeurs mises à jour
  EventState copyWith({
    String? free,
    EventStatus? status,
    List<Slot>? freeSlots,
  }) {
    return EventState(
      free: free ?? this.free,
      status: status ?? this.status,
      freeSlots: freeSlots ?? this.freeSlots,
    );
  }

  @override
  List<Object?> get props => [free, status, freeSlots];
}
