import 'package:flutter/material.dart';

import '../../../core/time/convert.dart';

class EventFreeItem extends StatelessWidget {
  final String slot;

  const EventFreeItem({
    Key? key,
    required this.slot,
  }) : super(key: key);

  // Méthode pour formater un objet DateTime en "HH:mm"
  String formatTime(DateTime dateTime) {
    return "${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}";
  }

  @override
  Widget build(BuildContext context) {
    final dateStart = convertSlotToDateTime(slot);
    final dateEnd = dateStart.add(const Duration(minutes: 30));

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      child: SizedBox(
        width: double.infinity,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${formatTime(dateStart)} - ${formatTime(dateEnd)}',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF027595),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
