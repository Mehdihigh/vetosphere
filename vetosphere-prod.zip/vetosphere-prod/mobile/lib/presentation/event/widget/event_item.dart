import 'package:flutter/material.dart';

class EventItem extends StatelessWidget {
  final String audioCenter; // Nom du centre audio
  final String dateStart; // Date et heure de début du rendez-vous (sous forme de chaîne)
  final Duration duration; // Durée du rendez-vous
  final Color color; // Couleur de fond de l'élément
  final String eventType; // Type de l'événement

  const EventItem({
    Key? key,
    required this.audioCenter,
    required this.dateStart,
    required this.duration,
    required this.color,
    required this.eventType,
  }) : super(key: key);

  // Formater la durée
  String formatDuration(Duration duration) {
    if (duration.inHours > 0 && duration.inMinutes.remainder(60) > 0) {
      return "${duration.inHours}h ${duration.inMinutes.remainder(60)}m";
    } else if (duration.inHours > 0) {
      return "${duration.inHours}h";
    } else {
      return "${duration.inMinutes}m";
    }
  }

  @override
  Widget build(BuildContext context) {
    final formattedDuration = formatDuration(duration);

    return Card(
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        color: color, // Couleur de fond
        child: SizedBox(
          width: double.infinity, // Définit la largeur à 100% de l'écran
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  audioCenter,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF027595),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  "Type : $eventType",
                  style: const TextStyle(fontSize: 16),
                ),
                const SizedBox(height: 8),
                Text(
                  "Date : $dateStart",
                  style: const TextStyle(fontSize: 16),
                ),
                const SizedBox(height: 8),
                Text(
                  "Durée : $formattedDuration",
                  style: const TextStyle(fontSize: 16),
                ),
              ],
            ),
          ),
        ),
    );
  }
}
