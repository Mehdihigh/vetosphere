import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:shadcn_ui/shadcn_ui.dart';

import '../viewModel/event_viewmodel.dart';
import '../widget/event_free_item.dart';
import '../widget/event_item.dart';
import '../../common/nav_bar.dart';

class EventScreen extends HookConsumerWidget {
  const EventScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final eventState = ref.watch(eventViewModelProvider);
    final eventViewModel = ref.read(eventViewModelProvider.notifier);

    return Scaffold(
      appBar: AppBar(),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const EventItem(
              audioCenter: 'Port de Bouc',
              dateStart: '15h00 27/01/2025',
              duration: Duration(hours: 0, minutes: 30),
              color: Color(0xFFFFDCB0),
              eventType: 'Réglage',
            ),
            const SizedBox(height: 16),
            const Text(
              "Sélectionnez une date",
              style: TextStyle(fontSize: 16),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            ShadDatePicker(
              onChanged: (date) {
                if (date != null) {
                  eventViewModel.freeAppointments(date.toIso8601String().split('T').first);
                }
              },
            ),
            const SizedBox(height: 16),
            if (eventState.freeSlots.isEmpty)
              const Center(
                child: Text(
                  "Aucun créneau disponible pour cette date.",
                  style: TextStyle(fontSize: 14, color: Colors.red),
                ),
              ),
            if (eventState.freeSlots.isNotEmpty)
              Expanded(
                child: ListView.builder(
                  itemCount: eventState.freeSlots.length,
                  itemBuilder: (context, index) {
                    final slot = eventState.freeSlots[index];
                    return EventFreeItem(slot: slot.slot);
                  },
                ),
              ),
          ],
        ),
      ),
      bottomNavigationBar: const NavigationBarApp(
        currentPageIndex: 1,
      ),
    );
  }
}
