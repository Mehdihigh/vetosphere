import 'package:equatable/equatable.dart';
import 'worker.dart'; // Importer le modèle Worker

class Document extends Equatable {
  final int id;
  final String fileName;
  final String type;
  final String createdAt;
  final Worker worker;

  const Document({
    required this.id,
    required this.fileName,
    required this.type,
    required this.createdAt,
    required this.worker,
  });

  @override
  List<Object?> get props => [id, fileName, type, createdAt, worker];

  factory Document.fromMap(Map<String, dynamic> map) {
    return Document(
      id: map['id_document'] as int,
      fileName: map['file_name'] as String,
      type: map['type'] as String,
      createdAt: map['creat'] as String,
      worker: Worker.fromMap(map['worker'] as Map<String, dynamic>),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id_document': id,
      'file_name': fileName,
      'type': type,
      'creat': createdAt,
      'worker': worker.toMap(),
    };
  }
}
