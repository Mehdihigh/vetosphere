import 'package:equatable/equatable.dart';

class Worker extends Equatable {
  final int idWorker;
  final String firstName;
  final String lastName;

  const Worker({
    required this.idWorker,
    required this.firstName,
    required this.lastName,
  });

  @override
  List<Object?> get props => [idWorker, firstName, lastName];

  factory Worker.fromMap(Map<String, dynamic> map) {
    return Worker(
      idWorker: map['id_worker'] ?? 0,
      firstName: map['firstName'] ?? '',
      lastName: map['lastName'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id_worker': idWorker,
      'firstName': firstName,
      'lastName': lastName,
    };
  }
}
