import 'package:equatable/equatable.dart';

class Mcq extends Equatable{
  final int idMcq;
  final String content;
  final String? type;

  const Mcq({
    required this.idMcq,
    required this.content,
    this.type,
  });

  @override
  List<Object?> get props => [
    idMcq,
    content,
    type,
  ];

  factory Mcq.fromMap(Map<String, dynamic> map) {
    return Mcq(
      idMcq: map['id_mcq'] as int,
      content: map['content'] as String,
      type: map['type'] as String?,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id_mcq': idMcq,
      'content': content,
      'type': type,
    };
  }
}
