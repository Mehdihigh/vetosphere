class Slot {
  final String slot;
  final bool setting;
  final bool test;

  const Slot({
    required this.slot,
    required this.setting,
    required this.test,
  });

  factory Slot.fromMap(Map<String, dynamic> map) {
    return Slot(
      slot: map['slot'] as String,
      setting: map['setting'] as bool,
      test: map['test'] as bool,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'slot': slot,
      'setting': setting,
      'test': test,
    };
  }
}
