import 'package:equatable/equatable.dart';
import 'mcq.dart';

class AttributMcq extends Equatable {
  final String state;
  final Mcq mcq;

  const AttributMcq({
    required this.state,
    required this.mcq,
  });

  @override
  List<Object?> get props => [
    state,
    mcq,
  ];
}
