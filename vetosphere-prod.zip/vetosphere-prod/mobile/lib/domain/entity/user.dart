import 'package:equatable/equatable.dart';

class User extends Equatable {
  final String lastName;
  final String firstName;
  final String? email;
  final String? address;
  final String? city;
  final String? postalCode;
  final String? dateOfBirth;
  final int? age;
  final String? gender;
  final String? createdAt;

  const User({
    required this.lastName,
    required this.firstName,
    this.email,
    this.address,
    this.city,
    this.postalCode,
    this.dateOfBirth,
    this.age,
    this.gender,
    this.createdAt,
  });

  @override
  List<Object?> get props => [
    lastName,
    firstName,
    email,
    address,
    city,
    postalCode,
    dateOfBirth,
    age,
    gender,
    createdAt,
  ];

  factory User.fromMap(Map<String, dynamic> map) {
    return User(
      lastName: map['lastName'] ?? '',
      firstName: map['firstName'] ?? '',
      email: map['email'] as String?,
      address: map['address'] as String?,
      city: map['city'] as String?,
      postalCode: map['postalCode'] as String?,
      dateOfBirth: map['date_birth'] as String?,
      age: map['age'] != null ? (map['age'] as num).toInt() : null,
      gender: map['gender'] as String?,
      createdAt: map['creat'] as String?,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'lastName': lastName,
      'firstName': firstName,
      'email': email,
      'address': address,
      'city': city,
      'postalCode': postalCode,
      'date_birth': dateOfBirth,
      'age': age,
      'gender': gender,
      'creat': createdAt,
    };
  }
}
