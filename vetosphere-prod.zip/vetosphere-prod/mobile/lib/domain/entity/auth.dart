import 'package:equatable/equatable.dart';

class Auth extends Equatable{
  final String jwt;

  const Auth({
    required this.jwt,
  });

  @override
  List<Object> get props => [
    jwt
  ];

}