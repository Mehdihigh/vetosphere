import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:im_audio_mobile/data/repository/auth_repository_impl.dart';
import 'package:im_audio_mobile/domain/repository/auth_repository.dart';
import '../entity/auth.dart';

final authUseCaseProvider =
    Provider<AuthUseCase>((ref)=> AuthUseCase(ref.read(authRepositoryProvider)));

class AuthUseCase{
  AuthUseCase(this._repository);

  final AuthRepository _repository;

  Future<Auth?> authentication({required String email, required String password}) {
    return _repository.authentication(email: email, password: password);
  }

}