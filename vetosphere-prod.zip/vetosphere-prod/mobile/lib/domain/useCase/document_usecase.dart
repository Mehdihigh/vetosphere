
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:im_audio_mobile/data/repository/user_document_repository_impl.dart';
import 'package:im_audio_mobile/domain/repository/document_repository.dart';

import '../entity/document.dart';

final documentUseCaseProvider = Provider<DocumentUseCase>(
    (ref) => DocumentUseCase(ref.read(userDocumentRepositoryProvider))
);

class DocumentUseCase {
  final DocumentRepository _repository;

  DocumentUseCase(this._repository);

  Future<List<Document>> getDocumentsByUser(){
    return _repository.getDocumentsByUser();
  }

}