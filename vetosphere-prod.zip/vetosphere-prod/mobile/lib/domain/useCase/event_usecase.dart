import 'package:hooks_riverpod/hooks_riverpod.dart';
import '../../data/repository/event_repository_impl.dart';
import '../entity/slot.dart';
import '../repository/event_repository.dart';

final eventUseCaseProvider =
  Provider<EventUseCase>((ref)=> EventUseCase(ref.read(eventRepositoryProvider)));

class EventUseCase{
  EventUseCase(this._repository);

  final EventRepository _repository;

  Future<List<Slot>> getFreeAppointments({required String date}) {
    return _repository.getFreeAppointments(date: date);
  }

}