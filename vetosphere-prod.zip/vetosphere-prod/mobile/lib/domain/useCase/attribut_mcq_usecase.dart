import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:im_audio_mobile/domain/repository/attribut_mcq_repository.dart';

import '../../data/repository/attribut_mcq_repository_impl.dart';
import '../entity/attribut_mcq.dart';

final attributMcqUseCaseProvider = Provider<AttributMcqUseCase>(
        (ref) => AttributMcqUseCase(ref.read(attributMcqRepositoryProvider)),
);

class AttributMcqUseCase{
  final AttributMcqRepository _repository;

  AttributMcqUseCase(this._repository);


  Future<List<AttributMcq>> getMcqByPatient(){
    return _repository.getMcqByPatient();
  }

}