import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:im_audio_mobile/data/repository/user_repository_impl.dart';
import 'package:im_audio_mobile/domain/repository/user_repository.dart';

import '../entity/user.dart';

final userUseCaseProvider = Provider<UserUseCase>(
    (ref) => UserUseCase(ref.read(userRepositoryProvider))
);

class UserUseCase{
  final UserRepository _repository;

  UserUseCase(this._repository);

  Future<User> getUserInfo(){

    return _repository.getUserInfo();
  }



}