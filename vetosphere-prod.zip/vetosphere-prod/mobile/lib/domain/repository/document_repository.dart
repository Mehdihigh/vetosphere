import '../entity/document.dart';

abstract class DocumentRepository {
  Future<List<Document>> getDocumentsByUser();
}
