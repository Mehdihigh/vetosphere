import '../entity/slot.dart';

abstract class EventRepository {
  Future<List<Slot>> getFreeAppointments({required String date});
}
