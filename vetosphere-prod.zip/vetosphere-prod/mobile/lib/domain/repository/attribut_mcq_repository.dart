import 'package:im_audio_mobile/domain/entity/attribut_mcq.dart';

abstract class AttributMcqRepository {
  Future<List<AttributMcq>> getMcqByPatient();
}