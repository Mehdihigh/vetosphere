import '../entity/auth.dart';

abstract class AuthRepository {
  Future<Auth?> authentication({required String email, required String password});
}