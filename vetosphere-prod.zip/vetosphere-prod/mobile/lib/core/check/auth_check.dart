import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../presentation/home/screen/home_screen.dart';
import '../../presentation/login/screen/login_screen.dart';
import '../../presentation/login/viewModel/login_state.dart';
import '../../presentation/login/viewModel/login_viewmodel.dart';


class AuthenticationWrapper extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Écoute l'état de LoginViewModel
    final loginState = ref.watch(loginViewModelProvider);

    if (loginState.status == LoginStatus.correct) {
      return const HomeScreen();
    } else {
      return const LoginScreen();
    }
  }
}
