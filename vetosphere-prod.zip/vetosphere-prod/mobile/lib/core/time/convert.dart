DateTime convertSlotToDateTime(String slot) {
  final parts = slot.split(':');
  final now = DateTime.now();
  return DateTime(
    now.year,
    now.month,
    now.day,
    int.parse(parts[0]),
    int.parse(parts[1]),
  );
}

String convertDate(String inputDate) {
  inputDate = inputDate.substring(0, inputDate.length - 1);
  inputDate = inputDate.replaceAll(" ", "T");
  String encodedDate = Uri.encodeFull(inputDate);
  return encodedDate;
}