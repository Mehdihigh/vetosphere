String formatDuration(Duration duration) {
  if (duration.inHours > 0 && duration.inMinutes.remainder(60) > 0) {
    return "${duration.inHours}h ${duration.inMinutes.remainder(60)}m";
  } else if (duration.inHours > 0) {
    return "${duration.inHours}h";
  } else {
    return "${duration.inMinutes}m";
  }
}
