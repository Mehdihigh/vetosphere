import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import '../../data/api/parameter_api.dart';
import '../cacheManager/jwtStorage.dart';

class DocumentDownloader {
  static Future<void> downloadDocument(int idDocument, String saveFileName) async {
    if (kIsWeb) {
      throw Exception("Le téléchargement sur le web n'est pas encore supporté");
    } else {
      final url = "${UrlApi.url}/user-document/download/$idDocument";
      final directory = Directory.systemTemp;
      final savePath = '${directory.path}/$saveFileName';
      final jwt = await JwtStorage.getToken();

      try {
        final dio = Dio();
        final response = await dio.download(
          url,
          savePath,
          options: Options(
            headers: {
              "Authorization": "Bearer $jwt",
              "Accept": "application/json",
            },
          ),
        );
        print("la : $response");
        if (response.statusCode == 200) {
          debugPrint("Fichier téléchargé avec succès : $savePath");
        } else {
          throw Exception("Erreur lors du téléchargement : Code ${response.statusCode}");
        }
      } catch (e) {
        throw Exception("Échec du téléchargement : $e");
      }
    }
  }
}
